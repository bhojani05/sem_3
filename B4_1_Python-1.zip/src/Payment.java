import java.util.*;

abstract class Payment
{
    protected Scanner sc = new Scanner(System.in);
    public abstract boolean processPayment();
}

class UPIPayment extends Payment {
    @Override
    public boolean processPayment() {
        while (true) {
            System.out.print("Enter UPI ID: ");
            String upi = sc.nextLine();
            if (upi.contains("@") && upi.indexOf("@") != upi.length() - 1) {
                System.out.println("Processing UPI Payment...");
                return OTPService.verifyOTP();
            } else {
                System.out.println("Invalid UPI ID, try again!");
            }
        }
    }
}

class NetBankingPayment extends Payment {
    @Override
    public boolean processPayment() {
        System.out.print("Enter User ID: ");
        String user = sc.nextLine();
        System.out.print("Enter Password: ");
        String pass = sc.nextLine();
        if (!user.isEmpty() && !pass.isEmpty()) {
            System.out.println("Processing NetBanking Payment...");
            return OTPService.verifyOTP();
        }
        return false;
    }
}

class CreditCardPayment extends Payment {
    @Override
    public boolean processPayment() {
        System.out.print("Enter Credit Card Number: ");
        String card = sc.nextLine();
        if (card.length() >= 12) {
            System.out.println("Processing Credit Card Payment...");
            return OTPService.verifyOTP();
        }
        return false;
    }
}

class OTPService {
    private static volatile boolean otpValid = true;

    public static boolean verifyOTP() {
        Scanner sc = new Scanner(System.in);
        String otp = generateOTP();

        Thread timer = new Thread(() -> {
            try {
                Thread.sleep(100000); //100 sec
                otpValid = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        timer.start();

        System.out.println("OTP Sent: " + otp + " (Valid for 100 seconds)");
        System.out.print("Enter OTP: ");
        String userOtp = sc.nextLine();

        if (otpValid && userOtp.equals(otp)) {
            System.out.println("OTP Verified, Payment Successful!");
            return true;
        } else {
            System.out.println("OTP Expired or Incorrect, Payment Failed.");
            return false;
        }
    }

    private static String generateOTP() {
        Random rand = new Random();
        int otp = 100000 + rand.nextInt(900000);  // 6 digit OTP
        return String.valueOf(otp);
    }
}


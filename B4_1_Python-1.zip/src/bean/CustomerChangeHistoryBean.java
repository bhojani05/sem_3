package bean;

public class CustomerChangeHistoryBean
{
    private int history_id; //PK
    private int cid; // FK
    private String field_changed;
    private String old_value;
    private String new_value;
    private String change_type;
    private String timestamp;

    // Getters and Setters
    public int getHistory_id() {
        return history_id;
    }
    public void setHistory_id(int history_id) {
        this.history_id = history_id;
    }

    public int getCid() {
        return cid;
    }
    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getField_changed() {
        return field_changed;
    }
    public void setField_changed(String field_changed) {
        this.field_changed = field_changed;
    }

    public String getOld_value() {
        return old_value;
    }
    public void setOld_value(String old_value) {
        this.old_value = old_value;
    }

    public String getNew_value() {
        return new_value;
    }
    public void setNew_value(String new_value) {
        this.new_value = new_value;
    }
}

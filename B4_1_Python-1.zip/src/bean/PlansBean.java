package bean;

public class PlansBean
{
    private int pid; //PK
    private int cid; //FK
    private String goal;
    private String intensity;
    private String dicttype;

    public void setCid(int cid) {
        this.cid = cid;
    }

    public int getCid() {
        return cid;
    }

    public String getGoal() {
        return goal;
    }
    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getIntensity() {
        return intensity;
    }
    public void setIntensity(String intensity) {
        this.intensity = intensity;
    }

    public String getDiettype() {
        return dicttype;
    }
    public void setDiettype(String dicttype) {
        this.dicttype = dicttype;
    }
}

package bean;

public class PaymentsBean
{
    private int payid; //PK
    private int cid; // FK
    private double amount;
    private String paymentdate;
    private String payment_mode;


    public int getCid() {
        return cid;
    }
    public void setCid(int cid) {
        this.cid = cid;
    }

    public double getAmount() {
        return amount;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPaymentdate() {
        return paymentdate;
    }
    public void setPaymentdate(String paymentdate) {
        this.paymentdate = paymentdate;
    }

    public String getPayment_mode() {
        return payment_mode;
    }
    public void setPayment_mode(String payment_mode) {
        this.payment_mode = payment_mode;
    }
}

package dao;
import bean.StaffInfoBean;
import util.InvalidEmailException;
import util.InvalidPhoneException;
import util.Validation;
import util.dbConnection;
import java.sql.*;
import java.util.*;

public class StaffInfoDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createStaffinfo = "CREATE TABLE IF NOT EXISTS StaffInfo (" +
                "  staff_id INT PRIMARY KEY AUTO_INCREMENT," +
                "  First_name VARCHAR(50) NOT NULL," +
                "  Last_name VARCHAR(50) NOT NULL," +
                "  staff_age INT," +
                "  email VARCHAR(100) UNIQUE,"+
                "  role VARCHAR(50)," +
                "  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "  gender VARCHAR(20)," +
                "  status VARCHAR(50)," +
                "  ph_no VARCHAR(20) UNIQUE)";
        st.executeUpdate(createStaffinfo);
    }

    public static void insert(StaffInfoBean a) throws Exception
    {
        String insertStaff ="INSERT INTO StaffInfo(First_name, Last_name, staff_age, email, role, gender, status, ph_no) " +
                            "VALUES (?,?,?,?,?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(insertStaff);

        try {
            ps.setString(4, a.getEmail());
        } catch (SQLException e) {
            System.out.println("Email already exists, Enter Different Email");
            while (true) {
                try {
                    System.out.print("Enter email: ");
                    String email = sc.nextLine().trim();
                    Validation.validateEmail(email);
                    a.setEmail(email);
                    break;
                } catch (InvalidEmailException e1) {
                    System.out.println(e1.getMessage());
                    insert(a);
                }
            }
        }
        try {
            ps.setString(8, a.getPh_no());
        } catch (SQLException e) {
            System.out.println("Phone number already exists, Enter Correct Phone Number");
            while (true) {
                try {
                    System.out.print("Enter phone number: ");
                    String phone = sc.nextLine().trim();
                    Validation.validatePhone(phone);
                    a.setPh_no(phone);
                    break;
                } catch (InvalidPhoneException e1) {
                    System.out.println(e1.getMessage());
                    insert(a);
                }
            }
        }
        ps.setString(1, a.getFirst_name());
        ps.setString(2, a.getLast_name());
        ps.setInt(3, a.getStaff_age());
        ps.setString(5, a.getRole());
        ps.setString(6, a.getGender());
        ps.setString(7, a.getStatus());

        ps.executeUpdate();
        System.out.println("Staff inserted successfully!");
    }

    public  static void update(StaffInfoBean a, int ch) throws Exception
    {
        String query = "";
        switch (ch) {
            case 1: query = "UPDATE StaffInfo SET staff_age=? WHERE staff_id=?"; break;
            case 2: query = "UPDATE StaffInfo SET email=? WHERE staff_id=?"; break;
            case 3: query = "UPDATE StaffInfo SET role=? WHERE staff_id=?"; break;
            case 4: query = "UPDATE StaffInfo SET status=? WHERE staff_id=?"; break;
            case 5: query = "UPDATE StaffInfo SET ph_no=? WHERE staff_id=?"; break;
        }
        PreparedStatement ps = con.prepareStatement(query);

        if (ch == 1) {
            ps.setInt(1, a.getStaff_age());
            ps.setInt(2, a.getStaff_id());
        } else if (ch == 2) {
            ps.setString(1, a.getEmail());
            ps.setInt(2, a.getStaff_id());
        } else if (ch == 3) {
            ps.setString(1, a.getRole());
            ps.setInt(2, a.getStaff_id());
        } else if (ch == 4) {
            ps.setString(1, a.getStatus());
            ps.setInt(2, a.getStaff_id());
        } else if (ch == 5) {
            ps.setString(1, a.getPh_no());
            ps.setInt(2, a.getStaff_id());
        }

        int rows = ps.executeUpdate();
        if (rows > 0) {
            System.out.println("Staff details updated successfully!");
        } else {
            System.out.println("No staff found with given phone number!");
        }
    }

    public  static void delete(StaffInfoBean a) throws Exception
    {
        String deleteStaff ="DELETE FROM StaffInfo WHERE email = ?";
        PreparedStatement ps = con.prepareStatement(deleteStaff);
        ps.setString(1, a.getEmail());
    }
}


package dao;
import bean.CustomerInfoBean;
import util.*;
import java.sql.*;
import java.util.Scanner;

public class CustomerInfoDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createCustomerInfo = "CREATE TABLE IF NOT EXISTS CustomerInfo (" +
                "  cid INT PRIMARY KEY AUTO_INCREMENT," +
                "  first_name VARCHAR(50) NOT NULL," +
                "  last_name VARCHAR(50)," +
                "  email VARCHAR(100) UNIQUE NOT NULL," +
                "  address VARCHAR(255)," +
                "  age INT," +
                "  gender VARCHAR(20)," +
                "  phone_number VARCHAR(20) UNIQUE NOT NULL)";
        st.executeUpdate(createCustomerInfo);
    }

    public static int insert(CustomerInfoBean c) throws Exception
    {
        String insertCustomerInfo = "INSERT INTO CustomerInfo(first_name, last_name, email, address, age, gender, phone_number) VALUES (?,?,?,?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(insertCustomerInfo);

        try {
            ps.setString(3, c.getEmail());
        } catch (SQLException e) {
            System.out.println("Email already exists, Enter Different Email");
            while (true) {
                try {
                    System.out.print("Enter email: ");
                    String email = sc.nextLine().trim();
                    Validation.validateEmail(email);
                    c.setEmail(email);
                    break;
                } catch (InvalidEmailException e1) {
                    System.out.println(e1.getMessage());
                    insert(c);
                }
            }
        }
        try {
            ps.setString(7, c.getPhone_number());
        } catch (SQLException e) {
            System.out.println("Phone number already exists, Enter Correct Phone Number");
            while (true) {
                try {
                    System.out.print("Enter phone number: ");
                    String phone = sc.nextLine().trim();
                    Validation.validatePhone(phone);
                    c.setPhone_number(phone);
                    break;
                } catch (InvalidPhoneException e1) {
                    System.out.println(e1.getMessage());
                    insert(c);
                }
            }
        }
        ps.setString(1, c.getFirst_name());
        ps.setString(2, c.getLast_name());
        ps.setString(4, c.getAddress());
        ps.setInt(5, c.getAge());
        ps.setString(6, c.getGender());
        ps.executeUpdate();

        String query = "SELECT cid FROM CustomerInfo WHERE email = ?";
        PreparedStatement ps2 = con.prepareStatement(query);
        ps2.setString(1, c.getEmail());
        ResultSet rs = ps2.executeQuery();
        if (rs.next()) {
            return rs.getInt("cid");
        }
        return 0;
    }

    public  static void update(CustomerInfoBean c, int choice) throws Exception
    {
        if(choice == 1)
        {
            String updateAge = "UPDATE CustomerInfo SET age = ? WHERE cid = ?";
            PreparedStatement ps = con.prepareStatement(updateAge);
            ps.setInt(1, c.getAge());
            ps.setInt(2, c.getCid());
            ps.executeUpdate();
        }
    }

    public  static void delete(CustomerInfoBean c) throws Exception
    {
        String deleteCustomerInfo = "DELETE FROM CustomerInfo WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(deleteCustomerInfo);
        ps.setInt(1, c.getCid());
    }
}

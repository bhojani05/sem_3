package dao;

import bean.CustomerBean;
import util.dbConnection;

import java.sql.*;
import java.util.Scanner;

public class CustomerDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws Exception
    {
        Statement st=con.createStatement();
        String createCustomer = "CREATE TABLE IF NOT EXISTS Customer (" +
                "  customer_id INT PRIMARY KEY AUTO_INCREMENT," +
                "  username VARCHAR(50) UNIQUE NOT NULL," +
                "  password VARCHAR(100) NOT NULL," +
                "  cid INT NOT NULL," +
                "  registration_date DATE DEFAULT CURRENT_DATE," +
                "  CONSTRAINT fk_customer_cid " +
                "  FOREIGN KEY (cid) REFERENCES CustomerInfo(cid) " +
                "  ON UPDATE CASCADE ON DELETE CASCADE)";
        st.executeUpdate(createCustomer);
    }
    public static void insert(CustomerBean c) throws Exception
    {
        String insert = "INSERT into Customer (username, password, cid) VALUES (?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(insert);
        try {
            ps.setString(1, c.getUsername());
        } catch (SQLException e) {
            System.out.println("Username already Taken, Enter Unique Username : ");
            c.setUsername(sc.nextLine());
            ps.setString(1, c.getUsername());
            insert(c);
        }
        ps.setString(2, c.getPassword());
        ps.setInt(3, c.getCid());
        ps.executeUpdate();
    }
    public  static void update(CustomerBean c) throws Exception
    {
        String updatePass = "UPDATE Customer SET password = ? WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(updatePass);
        ps.setString(1, c.getPassword());
        ps.setInt(2, c.getCid());
        ps.executeUpdate();
    }
    public  static void delete(CustomerBean c) throws Exception
    {
        String deleteCustomer = "DELETE FROM Customer where cid = ?";
        PreparedStatement ps = con.prepareStatement(deleteCustomer);
        ps.setInt(1, c.getCid());
    }

    public static int validateLogin(CustomerBean c) {
        String select = "SELECT ci.cid FROM Customer c JOIN CustomerInfo ci ON c.cid = ci.cid" +
                        " WHERE username=? AND password=?;";
        try (PreparedStatement ps = con.prepareStatement(select))
        {
            ps.setString(1, c.getUsername());
            ps.setString(2, c.getPassword());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1); // found user
            } else {
                return -1; // no user found
            }
        } catch (Exception e) {
            System.out.println("Login validation error: " + e.getMessage());
            return -1;
        }
    }

    public static boolean checkPassword(CustomerBean c) throws Exception
    {
        String select = "SELECT password FROM Customer WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(select);
        ps.setInt(1, c.getCid());
        ResultSet rs = ps.executeQuery();
        rs.next();
        return rs.getString(1).equals(c.getPassword());
    }

    public static String getUserName(CustomerBean c) throws Exception
    {
        String select = "SELECT username FROM Customer WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(select);
        ps.setInt(1, c.getCid());
        ResultSet rs = ps.executeQuery();
        rs.next();
        return rs.getString(1);
    }
}

package dao;
import bean.PlansBean;
import util.dbConnection;
import java.sql.*;
import java.util.*;

public class PlansDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createPlans = "CREATE TABLE IF NOT EXISTS Plans (" +
                "  pid INT PRIMARY KEY AUTO_INCREMENT," +
                "  cid INT NOT NULL," +
                "  goal VARCHAR(50)," +
                "  intensity VARCHAR(20)," +
                "  diettype VARCHAR(50)," +
                "  CONSTRAINT fk_plans_cid " +
                "  FOREIGN KEY (cid) REFERENCES CustomerInfo(cid) " +
                "  ON UPDATE CASCADE ON DELETE CASCADE)";
        st.executeUpdate(createPlans);
    }

    public static void insert(PlansBean p) throws Exception
    {
        String insertPlans ="INSERT INTO Plans(cid,goal,intensity,diettype) VALUES (?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(insertPlans);

        ps.setInt(1, p.getCid());
        ps.setString(2, p.getGoal());
        ps.setString(3, p.getIntensity());
        ps.setString(4, p.getDiettype());

        ps.executeUpdate();
        System.out.println("Plan inserted successfully!");
    }


    public  static void delete(PlansBean p) throws Exception
    {
        String deletePlans ="DELETE FROM Plans WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(deletePlans);
        ps.setInt(1, p.getCid());
    }

}

class PlanHistoryQueue {
    private String[] history;
    private int size;
    private static final int MAX = 50;
    private String[] purchaseHistory = new String[MAX];
    private int front = 0, rear = -1, count = 0;

    public PlanHistoryQueue() {}

    public PlanHistoryQueue(int capacity) {
        history = new String[capacity];
        size = 0;
    }

    public void enqueue(String plan) {
        if (size < history.length) {
            history[size++] = plan;
        } else {
            // shift left if full
            for (int i = 1; i < history.length; i++) {
                history[i - 1] = history[i];
            }
            history[history.length - 1] = plan;
        }
    }

    public void display() {
        if (size == 0) {
            System.out.println("No plans selected yet.");
            return;
        }
        System.out.println("Your last " + size + " plan selections:");
        for (int i = 0; i < size; i++) {
            System.out.println((i+1)+".) " + history[i]);
        }
    }

    public void addPlan(String planDetails) {
        rear = (rear + 1) % MAX;
        purchaseHistory[rear] = planDetails;

        if (count < MAX)
        {
            count++;
        } else
        {
            front = (front + 1) % MAX;
        }
    }

    public void displayPlans() {
        if (count == 0) {
            System.out.println("No plans purchased yet.");
            return;
        }

        System.out.println("Last " + count + " Plans Bought:");
        int i = front;
        for (int c = 0; c < count; c++) {
            System.out.println((c + 1) + ". " + purchaseHistory[i]);
            i = (i + 1) % MAX;
        }
    }
}
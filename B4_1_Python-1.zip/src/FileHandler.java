import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandler {

    public static void saveBill(String userName, int price, String dietType, String goal, String intensity) {
        String fileName = "D:/Bill_" + userName + ".txt";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write("========== FITNESS BILL ==========\n");
            bw.write("Customer: " + userName + "\n");
            bw.write("Total Price: Rs. " + price + "\n\n");

            if (price == 500 || price == 600) {
                bw.write("Plan Purchased: DIET PLAN (" + dietType + ")\n");
            } else if (price == 700) {
                bw.write("Plan Purchased: WORKOUT PLAN (" + goal + " - " + intensity + ")\n");
            } else {
                bw.write("Plan Purchased: DIET + WORKOUT\n");
            }

            bw.write("\nThank you for choosing our Fitness Plans!\n");
            bw.write("======================================\n");

            System.out.println("📄 Bill saved successfully in D: drive -> " + fileName);

        } catch (IOException e) {
            System.out.println("Error saving bill file: " + e.getMessage());
        }
    }

    public static void saveFullPlan(String userName, String dietContent, String workoutContent, String restrictions) {
        String fileName = "D:/Plan_" + userName + ".txt";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            bw.write("========== FITNESS PLAN ==========\n");
            bw.write("Customer: " + userName + "\n\n");

            if (dietContent != null && !dietContent.isEmpty()) {
                bw.write("----- DIET PLAN -----\n");
                bw.write(dietContent + "\n\n");
            }

            if (workoutContent != null && !workoutContent.isEmpty()) {
                bw.write("----- WORKOUT PLAN -----\n");
                bw.write(workoutContent + "\n\n");
            }

            if (restrictions != null && !restrictions.isEmpty()) {
                bw.write("----- MEDICAL RESTRICTIONS -----\n");
                bw.write(restrictions + "\n\n");
            }

            bw.write("Stay Healthy & Stay Fit 💪\n");
            bw.write("=================================\n");

            System.out.println("Full Plan saved successfully in D: drive -> " + fileName);

        } catch (IOException e) {
            System.out.println("Error saving plan file: " + e.getMessage());
        }
    }
}

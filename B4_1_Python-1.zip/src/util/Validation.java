package util;

public class Validation
{
    public static void validateName(String name) throws InvalidNameException {
        if (name == null || name.length() == 0)
            throw new InvalidNameException("Name cannot be empty.");
        for (int i = 0; i < name.length(); i++) {
            if (!Character.isLetter(name.charAt(i))) {
                throw new InvalidNameException("Name must contain only alphabets.");
            }
        }
    }

    public static void validatePhone(String phone) throws InvalidPhoneException {
        if (phone.length() != 10)
            throw new InvalidPhoneException("Phone number must be exactly 10 digits.");
        if (phone.charAt(0) == '0')
            throw new InvalidPhoneException("Phone number should not start with 0.");
        for (int i = 0; i < phone.length(); i++) {
            if (!Character.isDigit(phone.charAt(i))) {
                throw new InvalidPhoneException("Phone number must contain only digits.");
            }
        }
    }

    public static void validateEmail(String email) throws InvalidEmailException {
        if (email == null || !email.endsWith("@gmail.com")) {
            throw new InvalidEmailException("Email must end with @gmail.com.");
        }
    }

    public static void validatePassword(String password, String confirmPassword) throws InvalidPasswordException {
        if (!password.equals(confirmPassword)) {
            throw new InvalidPasswordException("Passwords do not match.");
        }
        if (password.length() < 8) {
            throw new InvalidPasswordException("Password must be at least 8 characters long.");
        }
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (Character.isUpperCase(ch)) hasUpper = true;
            else if (Character.isLowerCase(ch)) hasLower = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else hasSpecial = true;
        }
        if (!hasUpper || !hasLower || !hasDigit || !hasSpecial) {
            throw new InvalidPasswordException("Password must contain uppercase, lowercase, digit, and special character.");
        }
    }

    public static void validateAge(int age) throws InvalidAgeException {
        if (age <= 15 || age >=60) throw new InvalidAgeException("Age must be greater than 15 and less than 60.");
    }

    public static void validateHeight(double height) throws InvalidHeightException {
        if (height <= 0 || height>230) throw new InvalidHeightException("Invalid Height");
    }

    public static void validateWeight(double weight) throws InvalidWeightException {
        if (weight <= 0 || weight>999) throw new InvalidWeightException("Weight must be positive.");
    }

    public static void validateDuration(String duration) throws InvalidDurationException {
        if (duration.contains("-")) {
            throw new InvalidDurationException("Duration cannot be negative.");
        }
    }
}
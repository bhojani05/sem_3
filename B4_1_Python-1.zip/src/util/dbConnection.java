package util;

import java.sql.*;
public class dbConnection
{
    public static Connection getConnection() throws Exception
    {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/fitnessdb","root","");
    }
}
package util;

public class InvalidHeightException extends Exception {
    public InvalidHeightException(String msg) { super(msg); }
}

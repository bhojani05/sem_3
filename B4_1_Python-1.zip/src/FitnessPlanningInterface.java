import bean.*;
import dao.*;
import util.*;

import java.util.*;
import java.sql.*;
public class FitnessPlanningInterface
{
    static int customerCount =0;
    static int StaffCount =0;
    private static boolean isLoggedIn = false;
    private static int loggedInCid = -1;
    static PlanHistoryQueue currentUserPlans = null;
    static PlanHistoryQueue planHistory = new PlanHistoryQueue();
    static Scanner sc=new Scanner(System.in);
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        displayWelcomeMessage();
        while (true)
        {
            System.out.println("\n1. User Portal  2.Staff Login  3. Admin Login  4. Exit");
            int mainChoice = sc.nextInt();
            sc.nextLine();
            switch (mainChoice) {
                case 1: userPortal();
                    break;
                case 2: staffLogin();
                    break;
                case 3: adminLogin();
                    break;
                case 4:
                    System.out.println("\n======================================");
                    System.out.println("   Thank you for using KyberFit!\uD83D\uDE4F\uD83C\uDFFB");
                    System.out.println("   Stay healthy, stay strong 💪");
                    System.out.println("======================================\n");
                    System.exit(0);

                default:System.out.println("Invalid choice, try again.");
            }
        }
    }

    static void adminLogin() throws Exception {
        while (true)
        {
            System.out.print("Enter Admin Password: ");
            String password = sc.nextLine();
            if (password.equals("7777"))
            {
                System.out.println("Admin Login Successful!");
                adminMenu();
                break;
            }
            else
            {
                System.out.println("Incorrect Password! Try again.");
            }
        }
    }

    static void adminMenu() throws Exception {
        while (true)
        {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Manage Staff  2.View Analytics  3. View Last Plans Bought 4.Back To Main Menu");
            int adminChoice = sc.nextInt();
            sc.nextLine();

            switch (adminChoice)
            {
                case 1:
                    while (true) {
                        System.out.println("\nManage Staff:");
                        String admCount = "SELECT COUNT(*) FROM StaffINFO";
                        Statement st2 = con.createStatement();
                        ResultSet rst2 = st2.executeQuery(admCount);
                        rst2.next();
                        StaffCount = rst2.getInt(1);
                        System.out.println("Currently, there are " + StaffCount + " Staff Members.");

                        System.out.println("1. Display All Staff Members  2. Add Staff  3. Update Staff  4. Delete Staff  5. Back to Main Menu");
                        int ch = sc.nextInt();
                        sc.nextLine();
                        StaffInfoBean a = new StaffInfoBean();
                        switch (ch)
                        {
                            case 1:
                                if(StaffCount >0) {
                                    CallableStatement csmt = con.prepareCall("{call displayStaff()}");
                                    ResultSet rs = csmt.executeQuery();
                                    while (rs.next()) {
                                        System.out.println("Staff ID        : " + rs.getString(1));
                                        System.out.println("First name      : " + rs.getString(2));
                                        System.out.println("Last name       : " + rs.getString(3));
                                        System.out.println("Staff age       : " + rs.getInt(4));
                                        System.out.println("Staff email     : " + rs.getString(5));
                                        System.out.println("Staff role      : " + rs.getString(6));
                                        System.out.println("Staff gender    : " + rs.getString(7));
                                        System.out.println("Staff Status    : " + rs.getString(8));
                                        System.out.println("Staff phone     : " + rs.getString(9));
                                    }
                                }
                                break;

                            case 2:
                                while (true) {
                                    try {
                                        System.out.print("Enter First name : ");
                                        String fname = sc.nextLine().trim();
                                        Validation.validateName(fname);
                                        a.setFirst_name(fname);
                                        break;
                                    } catch (InvalidNameException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }

                                while (true) {
                                    try {
                                        System.out.print("Enter Last name : ");
                                        String lname = sc.nextLine().trim();
                                        Validation.validateName(lname);
                                        a.setLast_name(lname);
                                        break;
                                    } catch (InvalidNameException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }

                                while (true) {
                                    try {
                                        System.out.print("Enter age: ");
                                        int age = sc.nextInt();
                                        Validation.validateAge(age);
                                        a.setStaff_age(age);
                                        break;
                                    } catch (InvalidAgeException e) {
                                        System.out.println(e.getMessage());
                                    } catch (Exception e) {
                                        System.out.println("Invalid input! Enter a valid number.");
                                        sc.nextLine();
                                    }
                                }
                                sc.nextLine();

                                while (true) {
                                    try {
                                        System.out.print("Enter email: ");
                                        String email = sc.nextLine().trim();
                                        Validation.validateEmail(email);
                                        a.setEmail(email);
                                        break;
                                    } catch (InvalidEmailException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }

                                while (true) {
                                    try {
                                        System.out.print("Enter Role : ");
                                        String role = sc.nextLine().trim();
                                        Validation.validateName(role);
                                        a.setRole(role);
                                        break;
                                    } catch (InvalidNameException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }

                                while (true) {
                                    System.out.println("Enter gender: \n1) Male\n2) Female\n3) Other");
                                    int ch1 = sc.nextInt();
                                    sc.nextLine();
                                    if (ch1 == 1) { a.setGender("Male"); break; }
                                    else if (ch1 == 2) { a.setGender("Female"); break; }
                                    else if (ch1 == 3) { a.setGender("Other"); break; }
                                    else System.out.println("Invalid choice! Try again.");
                                }

                                a.setStatus("Active");

                                while (true) {
                                    try {
                                        System.out.print("Enter phone number: ");
                                        String phone = sc.nextLine().trim();
                                        Validation.validatePhone(phone);
                                        a.setPh_no(phone);
                                        break;
                                    } catch (InvalidPhoneException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                                StaffInfoDao.insert(a);
                                break;

                            case 3:
                                while (true) {
                                    try {
                                        while (true) {
                                            System.out.print("Enter Staff ID : ");
                                            int id = sc.nextInt();
                                            if (StaffCount < id || id < 0) {
                                                System.out.println("Enter valid Staff ID");
                                            } else {
                                                a.setStaff_id(id);
                                                break;
                                            }
                                        }
                                        System.out.println("What do you want to update?");
                                        System.out.println("1. Age\n2. Email\n3. Role\n4. Status (Active/Inactive)\n5. Phone Number");
                                        int upChoice = sc.nextInt();
                                        sc.nextLine();

                                        switch (upChoice) {
                                            case 1:
                                                while (true) {
                                                    try {
                                                        System.out.print("Enter new Age: ");
                                                        int newAge = sc.nextInt();
                                                        Validation.validateAge(newAge);
                                                        a.setStaff_age(newAge);
                                                        StaffInfoDao.update(a,1);
                                                        break;
                                                    } catch (InvalidAgeException e) {
                                                        System.out.println(e.getMessage());
                                                    } catch (Exception e) {
                                                        System.out.println("Invalid input! Enter a valid number.");
                                                        sc.nextLine();
                                                    }
                                                }
                                                break;

                                            case 2:
                                                while (true) {
                                                    try {
                                                        System.out.print("Enter new Email: ");
                                                        String newEmail = sc.nextLine().trim();
                                                        Validation.validateEmail(newEmail);
                                                        a.setEmail(newEmail);
                                                        StaffInfoDao.update(a,2);
                                                        break;
                                                    } catch (InvalidEmailException e) {
                                                        System.out.println(e.getMessage());
                                                    }
                                                }
                                                break;

                                            case 3:
                                                while (true) {
                                                    try {
                                                        System.out.print("Enter new Role: ");
                                                        String newRole = sc.nextLine().trim();
                                                        Validation.validateName(newRole);
                                                        a.setRole(newRole);
                                                        StaffInfoDao.update(a,3);
                                                        break;
                                                    } catch (InvalidNameException e) {
                                                        System.out.println(e.getMessage());
                                                    }
                                                }
                                                break;

                                            case 4:
                                                while (true) {
                                                    System.out.print("Enter new Status (1. Active / 2. Inactive): ");
                                                    int st = sc.nextInt();
                                                    sc.nextLine();
                                                    if (st == 1) {
                                                        a.setStatus("Active");
                                                        StaffInfoDao.update(a,4);
                                                        break;
                                                    } else if (st == 2) {
                                                        a.setStatus("Inactive");
                                                        StaffInfoDao.update(a,4);
                                                        break;
                                                    } else {
                                                        System.out.println("Invalid choice! Try again.");
                                                    }
                                                }
                                                break;

                                            case 5:
                                                while (true) {
                                                    try {
                                                        System.out.print("Enter new Phone Number: ");
                                                        String newPhone = sc.nextLine().trim();
                                                        Validation.validatePhone(newPhone);
                                                        a.setPh_no(newPhone);
                                                        StaffInfoDao.update(a,5);
                                                        break;
                                                    } catch (InvalidPhoneException e) {
                                                        System.out.println(e.getMessage());
                                                    }
                                                }
                                                break;

                                            default:
                                                System.out.println("Invalid choice!");
                                        }
                                        break;
                                    } catch (InvalidPhoneException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                                break;

                            case 4:
                                while (true) {
                                    try {
                                        System.out.print("Enter email of Staff whose data is to be deleted : ");
                                        String email = sc.nextLine().trim();
                                        Validation.validateEmail(email);
                                        a.setEmail(email);
                                        StaffInfoDao.delete(a);
                                        break;
                                    } catch (InvalidEmailException e) {
                                        System.out.println(e.getMessage());
                                    }
                                }
                                break;

                            case 5:return;

                            default:System.out.println("Invalid choice, try again.");

                        }

                    }

                case 2: String totalIncome = "SELECT SUM(AMOUNT) FROM PAYMENTS";
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery(totalIncome);
                        while (rs.next())
                        {
                            System.out.println("Total Income earned till date : "+rs.getString(1));
                        }
                        break;
                case 3:
                    planHistory.displayPlans();
                    break;
                case 4: System.out.println("Logging out Admin menu"); return;
                default: System.out.println("Invalid choice, try again.");
            }
        }
    }

    static void userPortal() throws Exception {
        while (true)
        {
            System.out.println("\nUser Portal:");
            System.out.println("1. Register as User\n2. Log In\n3. Back to Main Menu");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice)
            {
                case 1: registerUser(); break;
                case 2: loginUser(); break;
                case 3: return;
                default: System.out.println("Invalid choice, try again.");
            }
        }
    }

    static void registerUser() throws Exception
    {
        CustomerBean c =  new CustomerBean();
        CustomerInfoBean ci = new CustomerInfoBean();
        while (true) {
            try {
                System.out.print("Enter first name: ");
                String fname = sc.nextLine().trim();
                Validation.validateName(fname);
                ci.setFirst_name(fname);
                break;
            } catch (InvalidNameException e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.print("Enter last name: ");
                String lname = sc.nextLine().trim();
                Validation.validateName(lname);
                ci.setLast_name(lname);
                break;
            } catch (InvalidNameException e) {
                System.out.println(e.getMessage());
            }
        }

        System.out.print("Enter username: ");
        c.setUsername(sc.nextLine());

        while (true) {
            try {
                System.out.println("8-Digit Password, must contain uppercase, lowercase, digit, and special character");
                System.out.print("Enter password: ");
                String pass1 = sc.nextLine();
                System.out.print("Confirm password: ");
                String pass2 = sc.nextLine();
                Validation.validatePassword(pass1, pass2);
                c.setPassword(pass1);
                break;
            } catch (InvalidPasswordException e) {
                System.out.println(e.getMessage());
            }
        }

        while (true) {
            try {
                System.out.print("Enter email: ");
                String email = sc.nextLine().trim();
                Validation.validateEmail(email);
                ci.setEmail(email);
                break;
            } catch (InvalidEmailException e) {
                System.out.println(e.getMessage());
            }
        }

        System.out.println("Enter address : ");
        ci.setAddress(sc.nextLine());

        while (true) {
            try {
                System.out.print("Enter age: ");
                int age = sc.nextInt();
                Validation.validateAge(age);
                ci.setAge(age);
                break;
            } catch (InvalidAgeException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Invalid input! Enter a valid number.");
                sc.nextLine();
            }
        }
        sc.nextLine();

        while (true) {
            System.out.println("Enter gender: \n1) Male\n2) Female\n3) Other");
            int ch = sc.nextInt();
            sc.nextLine();
            if (ch == 1) { ci.setGender("Male"); break; }
            else if (ch == 2) { ci.setGender("Female"); break; }
            else if (ch == 3) { ci.setGender("Other"); break; }
            else System.out.println("Invalid choice! Try again.");
        }

        while (true) {
            try {
                System.out.print("Enter phone number: ");
                String phone = sc.nextLine().trim();
                Validation.validatePhone(phone);
                ci.setPhone_number(phone);
                break;
            } catch (InvalidPhoneException e) {
                System.out.println(e.getMessage());
            }
        }

        int cid = CustomerInfoDao.insert(ci);
        c.setCid(cid);
        CustomerDao.insert(c);

        CustomerMeasurementBean cmb = new CustomerMeasurementBean();
        cmb.setCustomerId(cid);

        while (true) {
            try {
                System.out.print("Enter Height in cm: ");
                double height = sc.nextDouble();
                Validation.validateHeight(height);
                cmb.setHeight(height);
                break;
            } catch (InvalidHeightException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Enter a valid number for height.");
                sc.nextLine();
            }
        }

        while (true) {
            try {
                System.out.print("Enter Weight in kg: ");
                double weight = sc.nextDouble();
                Validation.validateWeight(weight);
                cmb.setWeight(weight);
                break;
            } catch (InvalidWeightException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Enter a valid number for weight.");
                sc.nextLine();
            }
        }


        double bmi = (cmb.getWeight()*10000)/Math.pow(cmb.getHeight(),2);
        cmb.setBmi(bmi);
        if (bmi < 18.5) cmb.setBmiCategory("Underweight");
        else if (bmi < 24.9) cmb.setBmiCategory("Normal weight");
        else if (bmi < 29.9) cmb.setBmiCategory("Overweight");
        else  cmb.setBmiCategory("Obese");
        CustomerMeasurementDao.insert(cmb);

        MedicalHistoryBean mh1 = new MedicalHistoryBean();
        while (true) {
            System.out.println("Enter Disease : ");
            System.out.println("1. Diabetes\n2. Hypertension\n3. Lactose Intolerance\n" +
                    "4. Gluten Sensitivity\n5. Kidney Disease\n6. Heart Disease\n7. Asthma\n" +
                    "8. Knee Pain\n9. Back Pain\n10. None");
            int ch1 = sc.nextInt();
            sc.nextLine();
            if (ch1 >= 1 && ch1 <= 10) {
                String[] diseases = {"Diabetes","Hypertension","Lactose Intolerance","Gluten Sensitivity",
                        "Kidney Disease","Heart Disease","Asthma","Knee Pain","Back Pain","None"};
                mh1.setDisease_name(diseases[ch1 - 1]);
                break;
            } else System.out.println("Invalid choice! Try again.");
        }
        System.out.println("Describe Nature of disease : ");
        mh1.setNature(sc.nextLine());

        while (true) {
            try {
                System.out.print("Enter duration (e.g., 2 years, 6 months): ");
                String duration = sc.nextLine().trim();
                Validation.validateDuration(duration);
                mh1.setDuration(duration);
                break;
            } catch (InvalidDurationException e) {
                System.out.println(e.getMessage());
            }
        }

        System.out.println("Enter Medications if any : ");
        mh1.setMedications(sc.nextLine());
        mh1.setCid(cid);
        MedicalHistoryDao.insert(mh1);
        customerCount++;
        System.out.println("User registration successfully!");
    }

    static void staffLogin() throws Exception {
        while (true)
        {
            System.out.print("Enter Staff Password: ");
            String password = sc.nextLine();
            if (password.equals("4444"))
            {
                System.out.println("Staff Login Successful!");
                staffMenu();
                break;
            }
            else
            {
                System.out.println("Incorrect Password! Try again.");
            }
        }
    }
    public static void staffMenu() throws Exception
    {
        while (true)
        {
            System.out.println("\nManage Users:");
            String custCount = "SELECT COUNT(*) FROM CUSTOMERINFO";
            Statement st1 = con.createStatement();
            ResultSet rst = st1.executeQuery(custCount);
            rst.next();
            customerCount = rst.getInt(1);
            System.out.println("Currently, there are " + customerCount + " users.");
            if (customerCount > 0) {
                System.out.println("1. Display All Users  2. Remove a User  3. Back to Admin Menu");
                int choice = sc.nextInt();
                sc.nextLine();
                switch (choice) {
                    case 1:
                        CallableStatement csmt = con.prepareCall("{call displayUsers()}");
                        ResultSet rs = csmt.executeQuery();
                        while (rs.next()) {
                            System.out.println("Username         : " + rs.getString("Username"));
                            System.out.println("Name             : " + rs.getString("Name"));
                            System.out.println("Age              : " + rs.getInt("Age"));
                            System.out.println("Gender           : " + rs.getString("Gender"));
                            System.out.println("Email            : " + rs.getString("Email"));
                            System.out.println("Phone            : " + rs.getString("Phone"));
                            System.out.println("Address          : " + rs.getString("Address"));
                            System.out.println("Registration Date: " + rs.getDate("Registration_Date"));
                            System.out.println("Height (cm)      : " + rs.getDouble("Height"));
                            System.out.println("Weight (kg)      : " + rs.getDouble("Weight"));
                            System.out.println("BMI              : " + rs.getDouble("BMI"));
                            System.out.println("BMI Category     : " + rs.getString("BMI_Category"));
                            System.out.println("Recorded Date   : " + rs.getDate("Recorded_Date"));
                            System.out.println("Disease          : " + rs.getString("Disease"));
                            System.out.println("Nature           : " + rs.getString("Nature"));
                            System.out.println("Duration         : " + rs.getString("Duration"));
                            System.out.println("Medications      : " + rs.getString("Medications"));
                            System.out.println("Goal             : " + rs.getString("Goal"));
                            System.out.println("Intensity        : " + rs.getString("Intensity"));
                            System.out.println("Diet Type        : " + rs.getString("Diet_Type"));
                            System.out.println("--------------------------------------------------");
                        }
                        break;
                    case 2:
                        System.out.println("Enter c_id : ");
                        int c_id = sc.nextInt();
                        sc.nextLine();
                        String delete = "DELETE FROM customer WHERE cid = ?";
                        PreparedStatement psmt = con.prepareStatement(delete);
                        psmt.setInt(1, c_id);
                        psmt.executeUpdate();
                        System.out.println("Customer Deleted Successfully!");
                        break;
                    case 3:
                        return;
                    default:
                        System.out.println("Invalid choice, try again.");
                }
            }
        }
    }

    static void loginUser()
    {
        try {
            if (isLoggedIn) {
                System.out.println("Already logged in!");
                return;
            }

            CustomerBean c = new CustomerBean();
            System.out.print("Enter username: ");
            c.setUsername(sc.nextLine());
            System.out.print("Enter password: ");
            c.setPassword(sc.nextLine());

            int cid = CustomerDao.validateLogin(c);
            if (cid != -1) {
                isLoggedIn = true;
                loggedInCid = cid;
                currentUserPlans = new PlanHistoryQueue(5);
                System.out.println("Login successful! Welcome, " + c.getUsername());
                while(true) {
                    System.out.println("1. Select Plans\n2. Update Details\n3. View Plan\n4. Logout");
                    int choice = sc.nextInt();
                    sc.nextLine();
                    switch (choice) {
                        case 1: selectPlans(); break;
                        case 2: updateDetails(); break;
                        case 3: viewPlan(); break;
                        case 4: logout(); return;
                        default:
                            System.out.println("Invalid choice. Try again.");
                    }

                }
            } else {
                System.out.println("Invalid credentials!");
            }

        } catch (Exception e) {
            System.out.println("Error during login: " + e.getMessage());
        }
    }

    static void updateDetails() throws Exception
    {
        if (!isLoggedIn) {
            System.out.println("Please log in first!");
            return;
        }
        while (true)
        {
            System.out.println("Select the detail you want to update:");
            System.out.println("1. Age\n2. Height & Weight\n3. Weight\n4. Medical History\n5. Password\n"+
                                "6. UpdatePlan(Goal, Intensity or Diet Type)\n7. Back to User Menu");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice)
            {
                case 1:
                    CustomerInfoBean ci1 = new CustomerInfoBean();
                    while (true)
                    {
                        try {
                            System.out.print("Enter new age: ");
                            int age = sc.nextInt();
                            Validation.validateAge(age);
                            ci1.setCid(loggedInCid);
                            ci1.setAge(age);
                            break;
                        } catch (InvalidAgeException e) {
                            System.out.println(e.getMessage());
                        } catch (Exception e) {
                            System.out.println("Invalid input! Enter a valid number.");
                            sc.nextLine();
                        }
                    }
                    sc.nextLine();
                    CustomerInfoDao.update(ci1,choice);
                    break;
                case 2:
                    CustomerMeasurementBean cm1 = new CustomerMeasurementBean();
                    cm1.setCustomerId(loggedInCid);
                    while (true) {
                        try {
                            System.out.print("Enter New Height in cm: ");
                            double height = sc.nextDouble();
                            Validation.validateHeight(height);
                            cm1.setHeight(height);
                            break;
                        } catch (InvalidHeightException e) {
                            System.out.println(e.getMessage());
                        } catch (Exception e) {
                            System.out.println("Enter a valid number for height.");
                            sc.nextLine();
                        }
                    }

                    while (true) {
                        try {
                            System.out.print("Enter New Weight in kg: ");
                            double weight = sc.nextDouble();
                            Validation.validateWeight(weight);
                            cm1.setWeight(weight);
                            break;
                        } catch (InvalidWeightException e) {
                            System.out.println(e.getMessage());
                        } catch (Exception e) {
                            System.out.println("Enter a valid number for weight.");
                            sc.nextLine();
                        }
                    }
                    CustomerMeasurementDao.update(cm1,choice);
                    break;
                case 3:
                    CustomerMeasurementBean cm2 = new CustomerMeasurementBean();
                    cm2.setCustomerId(loggedInCid);
                    while (true)
                    {
                        try {
                            System.out.print("Enter New Weight in kg: ");
                            double weight = sc.nextDouble();
                            Validation.validateWeight(weight);
                            cm2.setWeight(weight);
                            break;
                        } catch (InvalidWeightException e) {
                            System.out.println(e.getMessage());
                        } catch (Exception e) {
                            System.out.println("Enter a valid number for weight.");
                            sc.nextLine();
                        }
                    }
                    CustomerMeasurementDao.update(cm2,choice);
                    break;
                case 4:
                    MedicalHistoryBean mh1 = new MedicalHistoryBean();
                    mh1.setCid(loggedInCid);
                    System.out.println("Do you want to add new medical history?\n1. Yes\n2. No, Just want to Update the old one");
                    if (sc.nextInt() == 1)
                    {
                        while (true) {
                            System.out.println("Enter New Disease : ");
                            System.out.println("1. Diabetes\n2. Hypertension\n3. Lactose Intolerance\n" +
                                    "4. Gluten Sensitivity\n5. Kidney Disease\n6. Heart Disease\n7. Asthma\n" +
                                    "8. Knee Pain\n9. Back Pain\n10. None");
                            int ch1 = sc.nextInt();
                            sc.nextLine();
                            if (ch1 >= 1 && ch1 <= 10) {
                                String[] diseases = {"Diabetes","Hypertension","Lactose Intolerance","Gluten Sensitivity",
                                        "Kidney Disease","Heart Disease","Asthma","Knee Pain","Back Pain","None"};
                                mh1.setDisease_name(diseases[ch1 - 1]);
                                break;
                            } else System.out.println("Invalid choice! Try again.");
                        }
                        System.out.println("Describe Nature of disease : ");
                        mh1.setNature(sc.nextLine());

                        while (true) {
                            try {
                                System.out.print("Enter duration (e.g., 2 years, 6 months): ");
                                String duration = sc.nextLine().trim();
                                Validation.validateDuration(duration);
                                mh1.setDuration(duration);
                                break;
                            } catch (InvalidDurationException e) {
                                System.out.println(e.getMessage());
                            }
                        }

                        System.out.println("Enter Medications if any : ");
                        mh1.setMedications(sc.nextLine());
                    }
                    else {
                        while (true) {
                            System.out.println("Enter New Disease : ");
                            System.out.println("1. Diabetes\n2. Hypertension\n3. Lactose Intolerance\n" +
                                    "4. Gluten Sensitivity\n5. Kidney Disease\n6. Heart Disease\n7. Asthma\n" +
                                    "8. Knee Pain\n9. Back Pain\n10. None");
                            int ch1 = sc.nextInt();
                            sc.nextLine();
                            if (ch1 >= 1 && ch1 <= 10) {
                                String[] diseases = {"Diabetes", "Hypertension", "Lactose Intolerance", "Gluten Sensitivity",
                                        "Kidney Disease", "Heart Disease", "Asthma", "Knee Pain", "Back Pain", "None"};
                                mh1.setDisease_name(diseases[ch1 - 1]);
                                break;
                            } else System.out.println("Invalid choice! Try again.");
                        }
                    }
                    MedicalHistoryDao.update(mh1);
                    break;
                case 5:
                    CustomerBean cb =  new CustomerBean();
                    System.out.println("Enter old password: ");
                    cb.setCid(loggedInCid);
                    cb.setPassword(sc.next());
                    boolean flag = CustomerDao.checkPassword(cb);
                    if(flag)
                    {
                        while (true) {
                            try {
                                System.out.print("Enter new password: ");
                                String pass1 = sc.nextLine();
                                System.out.print("Confirm new password: ");
                                String pass2 = sc.nextLine();
                                Validation.validatePassword(pass1, pass2);
                                cb.setPassword(pass1);
                                break;
                            } catch (InvalidPasswordException e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        CustomerDao.update(cb);
                    }
                    else
                    {
                        System.out.println("You entered wrong password!");
                    }
                    break;
                case 6:
                    while (true) {
                    System.out.println("To Update Goal or Intensity of Workout or Diet Type\nYou have to select new plan!");
                    System.out.println("Do you want to proceed\n1.)Yes\n2)No");
                    int ch = sc.nextInt();
                    if (ch == 1) { selectPlans(); break;}
                    else if (ch == 2) break;
                    else System.out.println("Invalid choice! Try again.");
                    }
                case 7:
                    System.out.println("Exiting update menu.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    static void selectPlans() throws Exception {
        if (!isLoggedIn) {
            System.out.println("Please log in first!");
            return;
        }
        PlansBean pb = new PlansBean();
        pb.setCid(loggedInCid);
        String goal = "";
        while (true) {
            try {
                System.out.println("Choose your fitness goal:");
                System.out.println("1. Muscle Gain\n2. Fat Loss\n3. Weight Gain");
                int g = Integer.parseInt(sc.nextLine());
                if (g == 1) { goal = "Muscle Gain"; break; }
                else if (g == 2) { goal = "Fat Loss"; break; }
                else if (g == 3) { goal = "Weight Gain"; break; }
                else System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number (1-3).");
            }
        }
        pb.setGoal(goal);

        String intensity = "";
        while (true) {
            try {
                System.out.println("Choose your workout intensity:");
                System.out.println("1. Intense\n2. Medium\n3. Low");
                int i = Integer.parseInt(sc.nextLine());
                if (i == 1) { intensity = "Intense"; break; }
                else if (i == 2) { intensity = "Medium"; break; }
                else if (i == 3) { intensity = "Low"; break; }
                else System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number (1-3).");
            }
        }
        pb.setIntensity(intensity);

        String dietType = "";
        while (true) {
            try {
                System.out.println("Choose your diet preference:");
                System.out.println("1. Vegetarian\n2. Non-Vegetarian");
                int d = Integer.parseInt(sc.nextLine());
                if (d == 1) { dietType = "Vegetarian"; break; }
                else if (d == 2) { dietType = "Non-Vegetarian"; break; }
                else System.out.println("Invalid choice. Please enter 1 or 2.");
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number (1-2).");
            }
        }
        pb.setDiettype(dietType);

        int price = 0;
        while (true) {
            try {
                System.out.println("Select your plan:");
                System.out.println("1. Only Diet Plan Veg=600Rs. and Non-Veg=500Rs.");
                System.out.println("2. Only Workout Plan = 700Rs.");
                System.out.println("3. Both Diet and Workout Plan Veg=1100Rs. and Non-Veg=1000Rs.");
                int planChoice = Integer.parseInt(sc.nextLine());

                if (planChoice == 1) {
                    price = (dietType.equals("Vegetarian")) ? 600 : 500;
                    System.out.println("You have chosen Only Diet Plan.");
                    currentUserPlans.enqueue("Diet Plan");
                    break;
                } else if (planChoice == 2) {
                    price = 700;
                    System.out.println("You have chosen Only Workout Plan.");
                    currentUserPlans.enqueue("Workout Plan");
                    break;
                } else if (planChoice == 3) {
                    price = (dietType.equals("Vegetarian")) ? 1100 : 1000;
                    System.out.println("You have chosen Both Diet and Workout Plan.");
                    currentUserPlans.enqueue("Both Diet + Workout Plan");
                    break;
                } else {
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number (1-3).");
            }
        }

        System.out.println("\nThe price for your personalized plan is " + price + "Rs.");

        int priceConfirmation = 0;
        while (true) {
            try {
                System.out.println("\nDo you agree to proceed?");
                System.out.println("1. Yes\n2. No");
                priceConfirmation = Integer.parseInt(sc.nextLine());
                if (priceConfirmation == 1 || priceConfirmation == 2) break;
                else System.out.println("Invalid choice. Please enter 1 or 2.");
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number (1-2).");
            }
        }

        if (priceConfirmation == 2) {
            System.out.println("\nNo worries! Here's a free tip: Stay consistent with your workouts!");
            return;
        }

        int paymentMode = 0;
        while (true) {
            try {
                System.out.println("Select payment mode : \n1) UPI \n2) Net Banking \n3) Credit Card");
                paymentMode = Integer.parseInt(sc.nextLine());
                if (paymentMode >= 1 && paymentMode <= 3) break;
                else System.out.println("Invalid choice. Please enter 1, 2 or 3.");
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number (1-3).");
            }
        }

        PaymentsBean p = new PaymentsBean();
        p.setCid(loggedInCid);
        p.setAmount(price);

        Payment payment = null;
        if (paymentMode == 1) { p.setPayment_mode("UPI"); payment = new UPIPayment(); }
        else if (paymentMode == 2) { p.setPayment_mode("Net Banking"); payment = new NetBankingPayment(); }
        else { p.setPayment_mode("Credit Card");payment = new CreditCardPayment(); }

        try {
            con.setAutoCommit(false);

            boolean paymentSuccess = payment.processPayment();

            if (!paymentSuccess) {
                throw new Exception("Payment Failed! Transaction aborted.");
            }

            PlansDao.insert(pb);

            con.commit();
            CustomerBean cb = new CustomerBean();
            cb.setCid(loggedInCid);
            String userName = CustomerDao.getUserName(cb);
            String dietPlanText = "";
            String workoutPlanText = "";
            String restrictionsText = "";
            if (price == 500 || price == 600) {
                planHistory.addPlan("User CID: " + loggedInCid + " | Plan: " + "Diet Plan");
                dietPlanText = displayDietPlan(dietType);
                restrictionsText = checkDietRestrictions(restrictionsText);
            } else if (price == 700) {
                planHistory.addPlan("User CID: " + loggedInCid + " | Plan: " + "Workout Plan");
                workoutPlanText = displayWorkoutPlan(goal, intensity);
                restrictionsText = checkMedicalWarnings(restrictionsText);

            } else {
                planHistory.addPlan("User CID: " + loggedInCid + " | Plan: " + "Diet + Workout Plan");
                dietPlanText = displayDietPlan(dietType);
                workoutPlanText = displayWorkoutPlan(goal, intensity);
                restrictionsText = checkDietRestrictions(restrictionsText);
                restrictionsText = restrictionsText + checkMedicalWarnings(restrictionsText);
            }
            FileHandler.saveBill(userName, price, dietType, goal, intensity);
            FileHandler.saveFullPlan(userName, dietPlanText, workoutPlanText, restrictionsText);
            PaymentsDao.insert(p);
            System.out.println("Plan Purchased Successfully! You paid: " + price + "Rs.");
            System.out.println("\nThank you for your purchase! Stay fit and healthy!");

        } catch (Exception e) {
            con.rollback();
            System.out.println("Transaction failed: " + e.getMessage());
        } finally {
            con.setAutoCommit(true);
        }
        System.out.println("Do you want to continue further?\n1. Yes\n2. No");
        int ch = sc.nextInt();
        if(ch == 1) logout();
        else if(ch == 2)
        {
            System.out.println("\n======================================");
            System.out.println("   Thank you for using KyberFit!\uD83D\uDE4F\uD83C\uDFFB");
            System.out.println("   Stay healthy, stay strong 💪");
            System.out.println("======================================\n");
            System.exit(0);
        }
        else System.out.println("Invalid choice! Try again.");
    }

    static void viewPlan() throws Exception
    {
        if (!isLoggedIn) {
            System.out.println("Please log in first!");
            return;
        }

        currentUserPlans.display();
    }

    static void logout()
    {
        if (isLoggedIn) {
            isLoggedIn = false;
            loggedInCid = -1;
            currentUserPlans = null;
            System.out.println("Logged out successfully!");
        } else {
            System.out.println("You are not logged in!");
        }
    }

    static void displayWelcomeMessage()
    {
        System.out.println("\n\n");
        System.out.println("=====================================================");
        System.out.println("||          Welcome to KyberFit!                   ||");
        System.out.println("|| Achieve your fitness goals with a custom plan.  ||");
        System.out.println("=====================================================\n");
    }

    static String displayDietPlan(String dietType) throws Exception {
        if (dietType.equals("Vegetarian"))
        {
            return  "\n- Drink plenty of water and herbal teas"+
                    "\n- **Breakfast:** Oats with fruits & nuts, or paneer sandwich with whole wheat bread."+
                    "\n- **Mid-morning snack:** Greek yogurt with honey, or a protein smoothie with banana & almonds."+
                    "\n- **Lunch:** Brown rice with dal, mixed vegetable curry, and salad; or quinoa with chickpeas & sauteed veggies."+
                    "\n- **Evening snack:** Roasted chana, peanut butter toast, or dry fruits."+
                    "\n- **Dinner:** Grilled tofu with stir-fried vegetables, or whole wheat chapati with dal and curd."+
                    "\n- **Additional Tips:**"+
                    "\n  -> Include protein-rich foods like lentils, beans, soya chunks, tofu, paneer, and quinoa."+
                    "\n  -> Ensure healthy fats from avocados, nuts, and olive oil."+
                    "\n  -> Drink plenty of water and herbal teas for hydration."+
                    "\n- -> Include green leafy vegetables and whole grains"+
                    "\n- -> Consume dairy for calcium and protein";
        }
        if (dietType.equals("Non-Vegetarian"))
        {
            return  "\n- **Breakfast:** Scrambled eggs with whole wheat toast, or chicken and vegetable omelet."+
                    "\n- **Mid-morning snack:** Boiled eggs with fruit, or a protein shake with nuts."+
                    "\n- **Lunch:** Grilled chicken/fish with quinoa and sauteed vegetables, or lean beef with brown rice & salad."+
                    "\n- **Evening snack:** Cottage cheese with nuts, tuna salad, or a protein bar."+
                    "\n- **Dinner:** Baked salmon with steamed broccoli, or grilled chicken with sweet potatoes."+
                    "\n- **Additional Tips:**"+
                    "\n  -> Prioritize lean protein sources such as chicken breast, fish, eggs, and lean beef."+
                    "\n  -> Include healthy fats from nuts, seeds, avocados and omega-3-rich fish."+
                    "\n  -> Stay hydrated with water and electrolyte-rich fluids."+
                    "\n- -> Eat fiber-rich vegetables and whole grains"+
                    "\n- -> Stay hydrated with water and electrolyte-rich fluids";
        }
        return "";
    }
    static String checkDietRestrictions(String restriction) throws Exception {
        MedicalHistoryBean mh =  new MedicalHistoryBean();
        mh.setCid(loggedInCid);
        String medicalHistory = MedicalHistoryDao.diseaseName(mh);
        if (medicalHistory.contains(" Diabetes"))
        {
            restriction =   "- Avoid sugary foods, processed carbs, and high-glycemic-index foods."+
                            "\n- Focus on complex carbs like whole grains and vegetables.";
        }
        if (medicalHistory.contains("Hypertension"))
        {
            restriction =   "- Avoid high-sodium and high-fat foods." +
                            "\n- Increase potassium intake (e.g., bananas, potatoes, spinach).";
        }
        if (medicalHistory.contains("Lactose Intolerance"))
        {
            restriction =   "- Avoid dairy or use lactose-free alternatives."+
                            "\n- Eat leafy greens, nuts, and calcium-rich foods.";
        }
        if (medicalHistory.contains("Gluten Sensitivity"))
        {
            restriction =   "- Avoid gluten-containing foods (e.g., wheat, barley, rye)."+
                            "\n- Focus on gluten-free grains like rice, quinoa, and oats.";
        }
        if (medicalHistory.contains("Kidney Disease"))
        {
            restriction =   "- Limit protein and potassium intake."+
                            "-\n Avoid high-sodium foods and processed meats.";
        }
        if (medicalHistory.contains("Heart Disease"))
        {
            restriction =   "- Avoid high-sodium foods, red meats, and processed foods."+
                            "\n- Focus on whole grains, lean meats, and healthy fats (e.g., olive oil).";
        }
        if (medicalHistory.contains("Asthma"))
        {
            restriction =   "- Avoid dairy, processed foods, and carbonated drinks."+
                            "\n- Eat omega-3 rich foods, vitamin D, and anti-inflammatory foods.";
        }
        if (medicalHistory.contains("Knee pain"))
        {
            restriction =   "- Recommended: Omega-3 rich fish, green leafy vegetables, turmeric, ginger, nuts."+
                            "\n- Avoid: Processed foods, excess sugar, high-sodium foods, alcohol.";
        }
        if (medicalHistory.contains("Back pain"))
        {
            restriction =   "- Recommended: Calcium-rich foods, leafy greens, dairy, almonds, seeds."+
                            "\n- Avoid: Caffeine, processed sugar, excessive red meat, fried foods.";
        }
        if (medicalHistory.contains("None"))
        {
            restriction = "None";
        }
        return restriction;
    }

    static String displayWorkoutPlan(String goal,String intensity) throws Exception {
        switch (goal)
        {
            case "Muscle Gain":
                if (intensity.equals("Low"))
                {
                    return  "\n- Focus: Strength training with progressive overload."+
                            "\n**Weekly Schedule (Low Intensity)**"+
                            "\nMonday: Light Upper Body (Machine Press, Lat Pulldown, Bicep Curls)"+
                            "\nTuesday: Light Lower Body (Leg Press, Seated Leg Curl, Calf Raises)"+
                            "\nWednesday: Active Recovery (Walking, Yoga, Mobility Exercises)"+
                            "\nThursday: Full-Body Resistance Band Training"+
                            "\nFriday: Cardio & Core (Brisk Walk, Planks, Russian Twists)"+
                            "\nSaturday: Rest"+
                            "\nSunday: Rest";
                }
                else if (intensity.equals("Medium"))
                {
                    return  "\n- Focus: Strength training with progressive overload."+
                            "\n**Weekly Schedule (Medium Intensity)**"+
                            "\nMonday: Chest & Triceps (Bench Press, Dips, Push-ups - 4 sets each)"+
                            "\nTuesday: Back & Biceps (Pull-ups, Barbell Rows, Dumbbell Curls)"+
                            "\nWednesday: Rest / Light Stretching"+
                            "\nThursday: Legs (Squats, Lunges, Leg Curls)"+
                            "\nFriday: Shoulders & Abs (Overhead Press, Lateral Raises, Crunches)"+
                            "\nSaturday: Light Full-body Cardio"+
                            "\nSunday: Rest";
                }
                else if (intensity.equals("Intense"))
                {
                    return  "\n- Focus: Strength training with progressive overload."+
                            "\n**Weekly Schedule (High Intensity)**"+
                            "\nMonday: Heavy Upper Body (Bench Press, Deadlifts, Pull-ups, Skull Crushers)"+
                            "\nTuesday: Heavy Lower Body (Squats, Romanian Deadlifts, Leg Press)"+
                            "\nWednesday: HIIT & Core (Burpees, Planks, Russian Twists)"+
                            "\nThursday: Chest & Arms (Dumbbell Press, Curls, Dips)"+
                            "\nFriday: Back & Legs (Pull-ups, Romanian Deadlifts, Bulgarian Split Squats)"+
                            "\nSaturday: Full-body HIIT (Jump Rope, Kettlebell Swings, Sprints)"+
                            "\nSunday: Rest / Recovery";
                }
                break;

            case "Fat Loss":
                if (intensity.equals("Low"))
                {
                    return  "\n- Focus: High-intensity interval training (HIIT) and endurance."+
                            "\n**Weekly Schedule (Low Intensity)**"+
                            "\nMonday: Walking & Bodyweight Squats"+
                            "\nTuesday: Light Cardio (Brisk Walking, Cycling)"+
                            "\nWednesday: Strength Training (Low Weights, High Reps)"+
                            "\nThursday: Rest"+
                            "\nFriday: Active Recovery (Yoga, Light Stretching)"+
                            "\nSaturday: Low-intensity Cardio & Core Work"+
                            "\nSunday: Rest";
                }
                else if (intensity.equals("Medium"))
                {
                    return  "\n- Focus: High-intensity interval training (HIIT) and endurance."+
                            "\n**Weekly Schedule (Medium Intensity)**"+
                            "\nMonday: HIIT (Jump Squats, Burpees, Mountain Climbers)"+
                            "\nTuesday: Cardio & Core (Running, Planks, Russian Twists)"+
                            "\nWednesday: Strength Training (Deadlifts, Squats, Bench Press)"+
                            "\nThursday: Rest"+
                            "\nFriday: HIIT & Cardio (Sprints, Jump Rope, Jumping Jacks)"+
                            "\nSaturday: Full-body Circuit Training"+
                            "\nSunday: Rest";
                }
                else if (intensity.equals("Intense"))
                {
                    return  "\n- Focus: High-intensity interval training (HIIT) and endurance."+
                            "\n**Weekly Schedule (High Intensity)**"+
                            "\nMonday: Advanced HIIT (Battle Ropes, Plyometric Lunges, Sprint Intervals)"+
                            "\nTuesday: Full-body Weight Training & Core (Power Cleans, Weighted Planks)"+
                            "\nWednesday: Rest"+
                            "\nThursday: Speed & Agility Drills (Sled Push, Lateral Hurdles)"+
                            "\nFriday: Strength Training & Cardio (Heavy Deadlifts, Treadmill Sprints)"+
                            "\nSaturday: Full-body CrossFit Circuit"+
                            "\nSunday: Rest";
                }
                break;

            case "Weight Gain":
                if (intensity.equals("Low"))
                {
                    return  "\n- Focus: Mass-building with compound movements."+
                            "\n**Weekly Schedule (Low Intensity)**"+
                            "\nMonday: Basic Weight Lifting (Light Dumbbells, Machines)"+
                            "\nTuesday: Rest & Recovery"+
                            "\nWednesday: Leg Day (Bodyweight Squats, Lunges)"+
                            "\nThursday: Rest"+
                            "\nFriday: Upper Body Strength (Push-ups, Shoulder Press)"+
                            "\nSaturday: Light Cardio & Mobility"+
                            "\nSunday: Rest";
                }
                else if (intensity.equals("Medium"))
                {
                    return  "\n- Focus: Mass-building with compound movements."+
                            "\n**Weekly Schedule (Medium Intensity)**"+
                            "\nMonday: Upper Body Strength (Bench Press, Shoulder Press, Rows)"+
                            "\nTuesday: Lower Body Strength (Squats, Lunges, Deadlifts)"+
                            "\nWednesday: Rest"+
                            "\nThursday: Chest & Arms (Dumbbell Press, Triceps Dips, Curls)"+
                            "\nFriday: Back & Legs (Pull-ups, Romanian Deadlifts, Leg Press)"+
                            "\nSaturday: Full-body & Functional Training"+
                            "\nSunday: Rest";
                }
                else if (intensity.equals("Intense"))
                {
                    return  "\n- Focus: Mass-building with compound movements."+
                            "\n**Weekly Schedule (High Intensity)**"+
                            "\nMonday: Heavy Chest & Triceps (Bench Press, Dips, Skull Crushers)"+
                            "\nTuesday: Heavy Leg Day (Squats, Deadlifts, Hip Thrusts)"+
                            "\nWednesday: HIIT & Core"+
                            "\nThursday: Arms & Shoulders (Overhead Press, Bicep Curls)"+
                            "\nFriday: Powerlifting Focus (Squats, Deadlifts, Power Cleans)"+
                            "\nSaturday: Sprint & Agility Training"+
                            "\nSunday: Rest / Mobility Drills";
                }
                break;
        }
        return "";
    }

    static String checkMedicalWarnings(String restriction) throws Exception {
        MedicalHistoryBean mh =  new MedicalHistoryBean();
        mh.setCid(loggedInCid);
        String medicalHistory = MedicalHistoryDao.diseaseName(mh);
        System.out.println("\n Medical History Warnings:");
        if (medicalHistory.contains("Diabetes"))
        {
            restriction = "\n Recommended: Strength training, moderate cardio, yoga."+
                          "\n Avoid: Prolonged high-intensity workouts, fasting workouts.";
        }
        if (medicalHistory.contains("Hypertension"))
        {
            restriction = "\n Recommended: Walking, resistance exercises with light weights."+
                          "\n Avoid: Heavy lifting, overhead presses, breath-holding.";
        }
        if (medicalHistory.contains("Lactose"))
        {
            restriction = "\n Recommended: Strength training, cardio, yoga."+
                          "\n Avoid: Exercises that cause excessive abdominal pressure.";
        }
        if (medicalHistory.contains("Gluten Sensitivity"))
        {
            restriction = "\nThere’s no specific exercise to avoid because of gluten sensitivity,"+
                          "\nbut being mindful of nutrition, cross-contamination, and joint health can help improve workout efficiency.";
        }
        if (medicalHistory.contains("Kidney Disease"))
        {
            restriction = "\n Recommended: Low-impact cardio, light strength training."+
                          "\n Avoid: High-protein bodybuilding, dehydration-prone exercises.";
        }
        if (medicalHistory.contains("Heart Disease"))
        {
            restriction = "\n Recommended: Light cardio, swimming, cycling."+
                          "\n Avoid: Heavy weightlifting, HIIT, sprinting.";
        }
        if (medicalHistory.contains("Asthma"))
        {
            restriction = "\n Recommended: Walking, yoga, swimming in warm water."+
                          "\n Avoid: Running, HIIT, cold-weather sports.";
        }
        if (medicalHistory.contains("Knee Pain"))
        {
            restriction = "\n Recommended: Swimming, cycling, leg raises."+
                          "\n Avoid: Deep squats, lunges, high-impact exercises.";
        }
        if (medicalHistory.contains("Back Pain"))
        {
            restriction = "\n Recommended: Swimming, core-strengthening workouts, planks."+
                          "\n Avoid: Deadlifts, heavy squats, crunches.";
        }
        if (medicalHistory.contains("None"))
        {
            restriction = "\nNone";
        }
        return restriction;
    }
}

